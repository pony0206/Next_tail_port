import image1 from '../images/sites/1/1.png';
import image2 from '../images/sites/1/2.png';
import image3 from '../images/sites/1/3.png';

import image4 from '../images/sites/2/1.png';
import image5 from '../images/sites/2/2.png';
import image6 from '../images/sites/2/3.png';

const images = [image1, image2, image3, image4, image5, image6];

export default images;
