const TitleText = (props: any) => {
  return <p className='text-[18px] mb-[20px]'>{props.data}</p>;
};

export default TitleText;
