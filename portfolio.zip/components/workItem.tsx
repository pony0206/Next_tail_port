const WorkItem = (props: any) => {
  return (
    <iframe
      src='https://www.starbucksreserve.com/'
      title='W3Schools Free Online Web Tutorials'
    ></iframe>
  );
};

export default WorkItem;
