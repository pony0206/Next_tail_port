const skills = [
  {
    name: 'React',
    value: 95,
  },
  {
    name: 'React',
    value: 95,
  },
  {
    name: 'React',
    value: 95,
  },
  {
    name: 'React',
    value: 95,
  },
  {
    name: 'React',
    value: 95,
  },
  {
    name: 'React',
    value: 95,
  },
  {
    name: 'React',
    value: 95,
  },
  {
    name: 'React',
    value: 95,
  },
];

export default skills;
